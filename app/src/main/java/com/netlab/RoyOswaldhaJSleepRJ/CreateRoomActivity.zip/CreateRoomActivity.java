package com.netlab.RoyOswaldhaJSleepRJ;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import com.netlab.RoyOswaldhaJSleepRJ.model.*;
import com.netlab.RoyOswaldhaJSleepRJ.model.City;
import com.netlab.RoyOswaldhaJSleepRJ.model.Facility;
import com.netlab.RoyOswaldhaJSleepRJ.request.BaseApiService;

import java.util.ArrayList;

import retrofit2.*;
public class CreateRoomActivity extends AppCompatActivity {
    BaseApiService mApiService;
    Button create, cancel;
    EditText roomName, roomPrice, roomAddress, roomSize;
    CheckBox WiFi, Bathtub, Balcony, AC, FitnessCenter, Refrigerator, Restaurant, SwimmingPool;
    Spinner city, bedType;
    private int roomPriceInt, roomSizeInt;
    private String cityInput, bedTypeInput, roomPriceString, roomSizeString;
    private City cityEnum;
    private BedType bedTypeEnum;

    Context mContext;
    private ArrayList<Facility> facilityInput = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_room);

        roomName = findViewById(R.id.createRoomName);
        roomPrice = findViewById(R.id.createRoomPrice);
        roomPriceString = roomPrice.getText().toString();
        roomPriceInt = 0;

        if (!"".equals(roomPriceString)) {
            roomPriceInt = Integer.parseInt(roomPriceString);
        }
        roomAddress = findViewById(R.id.createRoomAddress);
        roomSize = findViewById(R.id.createRoomSize);
        roomSizeString = roomSize.getText().toString();
        roomSizeInt = 0;
        if (!"".equals(roomSizeString)) {
            roomSizeInt = Integer.parseInt(roomSizeString);
        }

        create = (Button) findViewById(R.id.createRoomButton);
        cancel = (Button) findViewById(R.id.createRoomCancelButton);

        //Check Box
        WiFi = findViewById(R.id.facilityWifi);
        Bathtub = findViewById(R.id.facilityBathub);
        Balcony = findViewById(R.id.facilityBalcony);
        AC = findViewById(R.id.facilityAC);
        FitnessCenter = findViewById(R.id.facilityFitnessCenter);
        Refrigerator = findViewById(R.id.facilityRefrigerator);
        Restaurant = findViewById(R.id.facilityAC);
        SwimmingPool = findViewById(R.id.facilitySwimmingPool);

        //Spinner
        city = findViewById(R.id.spinnerCity);
        bedType = findViewById(R.id.spinnerBedType);
        //Spinner Input
        cityInput = city.getSelectedItem().toString();
        bedTypeInput = bedType.getSelectedItem().toString();

        if (cityInput.equalsIgnoreCase("Surabaya")) {
            cityEnum = City.SURABAYA;
        }
        if (cityInput.equalsIgnoreCase("Depok")) {
            cityEnum = City.DEPOK;
        }
        if (cityInput.equalsIgnoreCase("Lampung")) {
            cityEnum = City.LAMPUNG;
        }
        if (cityInput.equalsIgnoreCase("Jakarta")) {
            cityEnum = City.JAKARTA;
        }
        if (cityInput.equalsIgnoreCase("Bandung")) {
            cityEnum = City.BANDUNG;
        }
        if (cityInput.equalsIgnoreCase("Semarang")) {
            cityEnum = City.SEMARANG;
        }
        if (cityInput.equalsIgnoreCase("Medan")) {
            cityEnum = City.MEDAN;
        }
        if (cityInput.equalsIgnoreCase("Bekasi")) {
            cityEnum = City.BEKASI;
        }
        if (cityInput.equalsIgnoreCase("Bali")) {
            cityEnum = City.BALI;
        }

        if (bedTypeInput.equalsIgnoreCase("Single")) {
            bedTypeEnum = BedType.SINGLE;
        }
        if (bedTypeInput.equalsIgnoreCase("Queen")) {
            bedTypeEnum = BedType.QUEEN;
        }
        if (bedTypeInput.equalsIgnoreCase("King")) {
            bedTypeEnum = BedType.KING;
        }
        if (bedTypeInput.equalsIgnoreCase("Double")) {
            bedTypeEnum = BedType.DOUBLE;
        }
        //Check Box Input
        WiFi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (WiFi.isChecked()) {
                    facilityInput.add(Facility.WiFi);
                } else {
                    facilityInput.remove(Facility.WiFi);
                }
            }
        });

        Bathtub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Bathtub.isChecked()) {
                    facilityInput.add(Facility.Bathtub);
                } else {
                    facilityInput.remove(Facility.Bathtub);
                }
            }
        });

        Balcony.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Balcony.isChecked()) {
                    facilityInput.add(Facility.Balcony);
                } else {
                    facilityInput.remove(Facility.Balcony);
                }
            }
        });

        AC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (AC.isChecked()) {
                    facilityInput.add(Facility.AC);
                } else {
                    facilityInput.remove(Facility.AC);
                }
            }
        });

        FitnessCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (FitnessCenter.isChecked()) {
                    facilityInput.add(Facility.FitnessCenter);
                } else {
                    facilityInput.remove(Facility.FitnessCenter);
                }
            }
        });

        Refrigerator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Refrigerator.isChecked()) {
                    facilityInput.add(Facility.Refrigerator);
                } else {
                    facilityInput.remove(Facility.Refrigerator);
                }
            }
        });

        Restaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Restaurant.isChecked()) {
                    facilityInput.add(Facility.Restaurant);
                } else {
                    facilityInput.remove(Facility.Restaurant);
                }
            }
        });

        SwimmingPool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SwimmingPool.isChecked()) {
                    facilityInput.add(Facility.SwimmingPool);
                } else {
                    facilityInput.remove(Facility.SwimmingPool);
                }
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Room room = requestRoom();
            }
        });
    }

    protected Room requestRoom() {
        mApiService.requestRoom(0, "Mawar", 2, 2, this.facilityInput, City.BALI, "Melati", BedType.QUEEN).enqueue(new Callback<com.netlab.RoyOswaldhaJSleepRJ.model.Room>() {
            @Override
            public void onResponse(Call<com.netlab.RoyOswaldhaJSleepRJ.model.Room> call, Response<com.netlab.RoyOswaldhaJSleepRJ.model.Room> response) {
                com.netlab.RoyOswaldhaJSleepRJ.model.Room room = response.body();
            }

            @Override
            public void onFailure(Call<com.netlab.RoyOswaldhaJSleepRJ.model.Room> call, Throwable t) {
                t.printStackTrace();
            }
        });
        return null;
    }
}